import React from "react";

const YEAR_LABELS = { 1: "1st Year", 2: "2nd Year", 3: "3rd Year", 4: "4th Year" };

export default function StudentTable({ students, onEdit, onDelete }) {
  if (students.length === 0) {
    return <p className="empty-state">No students found.</p>;
  }

  return (
    <div className="table-wrapper">
      <table className="student-table">
        <thead>
          <tr>
            <th>Name</th>
            <th>Email</th>
            <th>Roll No.</th>
            <th>Department</th>
            <th>Year</th>
            <th>Phone</th>
            <th>Actions</th>
          </tr>
        </thead>
        <tbody>
          {students.map((student) => (
            <tr key={student.id}>
              <td>{student.name}</td>
              <td>{student.email}</td>
              <td>{student.roll_number}</td>
              <td>{student.department}</td>
              <td>{YEAR_LABELS[student.year] || student.year}</td>
              <td>{student.phone}</td>
              <td className="actions-cell">
                <button className="btn btn-small" onClick={() => onEdit(student)}>
                  Edit
                </button>
                <button
                  className="btn btn-small btn-danger"
                  onClick={() => onDelete(student)}
                >
                  Delete
                </button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
