import React, { useEffect, useState } from "react";

const emptyForm = {
  name: "",
  email: "",
  roll_number: "",
  department: "",
  year: 1,
  phone: "",
};

const EMAIL_REGEX = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
const PHONE_REGEX = /^\+?\d{7,15}$/;

export default function StudentForm({ editingStudent, onSubmit, onCancel, serverErrors }) {
  const [form, setForm] = useState(emptyForm);
  const [clientErrors, setClientErrors] = useState({});

  useEffect(() => {
    if (editingStudent) {
      setForm({
        name: editingStudent.name,
        email: editingStudent.email,
        roll_number: editingStudent.roll_number,
        department: editingStudent.department,
        year: editingStudent.year,
        phone: editingStudent.phone,
      });
    } else {
      setForm(emptyForm);
    }
    setClientErrors({});
  }, [editingStudent]);

  const validate = () => {
    const errors = {};
    if (!form.name.trim()) errors.name = "Name is required.";
    if (!form.email.trim()) {
      errors.email = "Email is required.";
    } else if (!EMAIL_REGEX.test(form.email)) {
      errors.email = "Enter a valid email address.";
    }
    if (!form.roll_number.trim()) errors.roll_number = "Roll number is required.";
    if (!form.department.trim()) errors.department = "Department is required.";
    if (!form.phone.trim()) {
      errors.phone = "Phone is required.";
    } else if (!PHONE_REGEX.test(form.phone)) {
      errors.phone = "Enter 7-15 digits, optionally starting with '+'.";
    }
    return errors;
  };

  const handleChange = (e) => {
    const { name, value } = e.target;
    setForm((prev) => ({ ...prev, [name]: name === "year" ? Number(value) : value }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    const errors = validate();
    setClientErrors(errors);
    if (Object.keys(errors).length === 0) {
      onSubmit(form);
    }
  };

  const fieldError = (field) => clientErrors[field] || serverErrors?.[field];

  return (
    <form className="student-form" onSubmit={handleSubmit} noValidate>
      <h2>{editingStudent ? "Edit Student" : "Add Student"}</h2>

      <div className="form-row">
        <label htmlFor="name">Name</label>
        <input id="name" name="name" value={form.name} onChange={handleChange} />
        {fieldError("name") && <span className="error-text">{fieldError("name")}</span>}
      </div>

      <div className="form-row">
        <label htmlFor="email">Email</label>
        <input id="email" name="email" type="email" value={form.email} onChange={handleChange} />
        {fieldError("email") && <span className="error-text">{fieldError("email")}</span>}
      </div>

      <div className="form-row">
        <label htmlFor="roll_number">Roll Number</label>
        <input id="roll_number" name="roll_number" value={form.roll_number} onChange={handleChange} />
        {fieldError("roll_number") && <span className="error-text">{fieldError("roll_number")}</span>}
      </div>

      <div className="form-row">
        <label htmlFor="department">Department</label>
        <input id="department" name="department" value={form.department} onChange={handleChange} />
        {fieldError("department") && <span className="error-text">{fieldError("department")}</span>}
      </div>

      <div className="form-row">
        <label htmlFor="year">Year</label>
        <select id="year" name="year" value={form.year} onChange={handleChange}>
          <option value={1}>1st Year</option>
          <option value={2}>2nd Year</option>
          <option value={3}>3rd Year</option>
          <option value={4}>4th Year</option>
        </select>
      </div>

      <div className="form-row">
        <label htmlFor="phone">Phone</label>
        <input id="phone" name="phone" value={form.phone} onChange={handleChange} placeholder="+919876543210" />
        {fieldError("phone") && <span className="error-text">{fieldError("phone")}</span>}
      </div>

      <div className="form-actions">
        <button type="submit" className="btn btn-primary">
          {editingStudent ? "Save Changes" : "Add Student"}
        </button>
        {editingStudent && (
          <button type="button" className="btn btn-secondary" onClick={onCancel}>
            Cancel
          </button>
        )}
      </div>
    </form>
  );
}
