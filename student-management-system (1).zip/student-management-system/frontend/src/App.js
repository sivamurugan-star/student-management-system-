import React, { useEffect, useState, useCallback } from "react";
import StudentForm from "./components/StudentForm";
import StudentTable from "./components/StudentTable";
import ConfirmDialog from "./components/ConfirmDialog";
import { fetchStudents, createStudent, updateStudent, deleteStudent } from "./api";
import "./App.css";

export default function App() {
  const [students, setStudents] = useState([]);
  const [loading, setLoading] = useState(true);
  const [loadError, setLoadError] = useState("");
  const [searchTerm, setSearchTerm] = useState("");
  const [editingStudent, setEditingStudent] = useState(null);
  const [serverErrors, setServerErrors] = useState({});
  const [pendingDelete, setPendingDelete] = useState(null);
  const [toast, setToast] = useState(null);

  const loadStudents = useCallback(async (search = "") => {
    setLoading(true);
    setLoadError("");
    try {
      const data = await fetchStudents({ search });
      setStudents(data);
    } catch (err) {
      setLoadError("Could not reach the server. Confirm the backend is running on port 8000.");
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    loadStudents();
  }, [loadStudents]);

  const showToast = (message, kind = "success") => {
    setToast({ message, kind });
    setTimeout(() => setToast(null), 3000);
  };

  const handleSearchSubmit = (e) => {
    e.preventDefault();
    loadStudents(searchTerm);
  };

  const handleFormSubmit = async (formData) => {
    setServerErrors({});
    try {
      if (editingStudent) {
        await updateStudent(editingStudent.id, formData);
        showToast("Student record updated.");
      } else {
        await createStudent(formData);
        showToast("Student added.");
      }
      setEditingStudent(null);
      loadStudents(searchTerm);
    } catch (err) {
      if (err.status === 400 && err.data) {
        setServerErrors(err.data);
      } else {
        showToast("Something went wrong. Please try again.", "error");
      }
    }
  };

  const handleDeleteConfirmed = async () => {
    try {
      await deleteStudent(pendingDelete.id);
      showToast("Student removed.");
      loadStudents(searchTerm);
    } catch (err) {
      showToast("Could not delete this record.", "error");
    } finally {
      setPendingDelete(null);
    }
  };

  return (
    <div className="app-shell">
      <header className="app-header">
        <div className="header-inner">
          <p className="header-kicker">Registrar's Office</p>
          <h1>Student Records</h1>
        </div>
      </header>

      <main className="app-main">
        <section className="panel form-panel">
          <StudentForm
            editingStudent={editingStudent}
            onSubmit={handleFormSubmit}
            onCancel={() => {
              setEditingStudent(null);
              setServerErrors({});
            }}
            serverErrors={serverErrors}
          />
        </section>

        <section className="panel table-panel">
          <div className="table-panel-header">
            <h2>All Students</h2>
            <form className="search-form" onSubmit={handleSearchSubmit}>
              <input
                type="text"
                placeholder="Search by name, email, or roll number"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
              />
              <button type="submit" className="btn btn-secondary">
                Search
              </button>
            </form>
          </div>

          {loading && <p className="status-text">Loading records…</p>}
          {loadError && <p className="status-text error-text">{loadError}</p>}
          {!loading && !loadError && (
            <StudentTable
              students={students}
              onEdit={(student) => {
                setEditingStudent(student);
                setServerErrors({});
              }}
              onDelete={(student) => setPendingDelete(student)}
            />
          )}
        </section>
      </main>

      {pendingDelete && (
        <ConfirmDialog
          message={`Remove ${pendingDelete.name} (${pendingDelete.roll_number}) from records?`}
          onConfirm={handleDeleteConfirmed}
          onCancel={() => setPendingDelete(null)}
        />
      )}

      {toast && <div className={`toast toast-${toast.kind}`}>{toast.message}</div>}
    </div>
  );
}
