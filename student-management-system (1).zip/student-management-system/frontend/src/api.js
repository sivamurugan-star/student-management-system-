const API_BASE_URL = process.env.REACT_APP_API_BASE_URL || "http://127.0.0.1:8000/api";

async function handleResponse(response) {
  if (response.status === 204) {
    return null;
  }
  const data = await response.json().catch(() => null);
  if (!response.ok) {
    const error = new Error("Request failed");
    error.status = response.status;
    error.data = data;
    throw error;
  }
  return data;
}

export async function fetchStudents(params = {}) {
  const query = new URLSearchParams(
    Object.fromEntries(Object.entries(params).filter(([, v]) => v))
  ).toString();
  const url = `${API_BASE_URL}/students/${query ? `?${query}` : ""}`;
  const response = await fetch(url);
  const data = await handleResponse(response);
  // Handle both paginated ({results: [...]}) and plain array responses.
  return Array.isArray(data) ? data : data?.results || [];
}

export async function createStudent(payload) {
  const response = await fetch(`${API_BASE_URL}/students/`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(payload),
  });
  return handleResponse(response);
}

export async function updateStudent(id, payload) {
  const response = await fetch(`${API_BASE_URL}/students/${id}/`, {
    method: "PUT",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(payload),
  });
  return handleResponse(response);
}

export async function deleteStudent(id) {
  const response = await fetch(`${API_BASE_URL}/students/${id}/`, {
    method: "DELETE",
  });
  return handleResponse(response);
}
