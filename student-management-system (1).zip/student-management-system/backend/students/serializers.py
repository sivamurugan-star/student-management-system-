from rest_framework import serializers

from .models import Student


class StudentSerializer(serializers.ModelSerializer):
    class Meta:
        model = Student
        fields = [
            "id",
            "name",
            "email",
            "roll_number",
            "department",
            "year",
            "phone",
            "created_at",
            "updated_at",
        ]
        read_only_fields = ["id", "created_at", "updated_at"]

    def validate_name(self, value):
        if not value.strip():
            raise serializers.ValidationError("Name cannot be empty.")
        return value.strip()

    def validate_department(self, value):
        if not value.strip():
            raise serializers.ValidationError("Department cannot be empty.")
        return value.strip()

    def validate_roll_number(self, value):
        if not value.strip():
            raise serializers.ValidationError("Roll number cannot be empty.")
        return value.strip()

    def validate_email(self, value):
        # EmailField already checks format; this enforces a clean duplicate
        # error message rather than a raw database IntegrityError (SOP 9).
        qs = Student.objects.filter(email__iexact=value)
        if self.instance:
            qs = qs.exclude(pk=self.instance.pk)
        if qs.exists():
            raise serializers.ValidationError("A student with this email already exists.")
        return value

    def validate(self, attrs):
        roll_number = attrs.get("roll_number", getattr(self.instance, "roll_number", None))
        if roll_number:
            qs = Student.objects.filter(roll_number__iexact=roll_number)
            if self.instance:
                qs = qs.exclude(pk=self.instance.pk)
            if qs.exists():
                raise serializers.ValidationError(
                    {"roll_number": "A student with this roll number already exists."}
                )
        return attrs
