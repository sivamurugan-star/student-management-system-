from django.core.validators import RegexValidator
from django.db import models


class Student(models.Model):
    """
    Core entity for the Student Management System.

    Field-level constraints (NOT NULL / UNIQUE / format) are enforced here
    at the database layer, and re-checked in the serializer for clean
    server-side validation error messages (per SOP section 9).
    """

    YEAR_CHOICES = [
        (1, "1st Year"),
        (2, "2nd Year"),
        (3, "3rd Year"),
        (4, "4th Year"),
    ]

    phone_validator = RegexValidator(
        regex=r"^\+?\d{7,15}$",
        message="Phone number must contain 7 to 15 digits, optionally starting with '+'.",
    )

    name = models.CharField(max_length=100)
    email = models.EmailField(unique=True)
    roll_number = models.CharField(max_length=20, unique=True)
    department = models.CharField(max_length=100)
    year = models.PositiveSmallIntegerField(choices=YEAR_CHOICES)
    phone = models.CharField(max_length=15, validators=[phone_validator])
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        ordering = ["-created_at"]

    def __str__(self):
        return f"{self.name} ({self.roll_number})"
