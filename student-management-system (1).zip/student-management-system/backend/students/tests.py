from django.urls import reverse
from rest_framework import status
from rest_framework.test import APITestCase

from .models import Student


class StudentCRUDTests(APITestCase):
    def setUp(self):
        self.list_url = reverse("student-list-create")
        self.valid_payload = {
            "name": "Asha Rao",
            "email": "asha.rao@example.com",
            "roll_number": "CS2024001",
            "department": "Computer Science",
            "year": 2,
            "phone": "+919876543210",
        }

    def test_create_student_valid(self):
        response = self.client.post(self.list_url, self.valid_payload, format="json")
        self.assertEqual(response.status_code, status.HTTP_201_CREATED)
        self.assertEqual(Student.objects.count(), 1)

    def test_create_student_missing_required_field(self):
        payload = self.valid_payload.copy()
        payload.pop("name")
        response = self.client.post(self.list_url, payload, format="json")
        self.assertEqual(response.status_code, status.HTTP_400_BAD_REQUEST)

    def test_create_student_duplicate_email(self):
        self.client.post(self.list_url, self.valid_payload, format="json")
        duplicate = self.valid_payload.copy()
        duplicate["roll_number"] = "CS2024002"
        response = self.client.post(self.list_url, duplicate, format="json")
        self.assertEqual(response.status_code, status.HTTP_400_BAD_REQUEST)
        self.assertIn("email", response.data)

    def test_create_student_invalid_email_format(self):
        payload = self.valid_payload.copy()
        payload["email"] = "not-an-email"
        response = self.client.post(self.list_url, payload, format="json")
        self.assertEqual(response.status_code, status.HTTP_400_BAD_REQUEST)

    def test_read_all_students_empty(self):
        response = self.client.get(self.list_url)
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertEqual(len(response.data["results"]) if "results" in response.data else len(response.data), 0)

    def test_read_all_students_populated(self):
        self.client.post(self.list_url, self.valid_payload, format="json")
        response = self.client.get(self.list_url)
        self.assertEqual(response.status_code, status.HTTP_200_OK)

    def test_update_student_valid_id(self):
        create_resp = self.client.post(self.list_url, self.valid_payload, format="json")
        student_id = create_resp.data["id"]
        detail_url = reverse("student-detail", args=[student_id])
        updated = self.valid_payload.copy()
        updated["name"] = "Asha K. Rao"
        response = self.client.put(detail_url, updated, format="json")
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertEqual(response.data["name"], "Asha K. Rao")

    def test_update_student_invalid_id(self):
        detail_url = reverse("student-detail", args=[9999])
        response = self.client.put(detail_url, self.valid_payload, format="json")
        self.assertEqual(response.status_code, status.HTTP_404_NOT_FOUND)

    def test_delete_student_valid_id(self):
        create_resp = self.client.post(self.list_url, self.valid_payload, format="json")
        student_id = create_resp.data["id"]
        detail_url = reverse("student-detail", args=[student_id])
        response = self.client.delete(detail_url)
        self.assertEqual(response.status_code, status.HTTP_204_NO_CONTENT)
        self.assertEqual(Student.objects.count(), 0)

    def test_delete_student_invalid_id(self):
        detail_url = reverse("student-detail", args=[9999])
        response = self.client.delete(detail_url)
        self.assertEqual(response.status_code, status.HTTP_404_NOT_FOUND)

    def test_search_by_name(self):
        self.client.post(self.list_url, self.valid_payload, format="json")
        response = self.client.get(self.list_url, {"search": "Asha"})
        self.assertEqual(response.status_code, status.HTTP_200_OK)
